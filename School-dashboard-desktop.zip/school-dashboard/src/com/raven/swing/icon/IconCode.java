package com.raven.swing.icon;

public interface IconCode {

    String name();

    char getUnicode();

    String getFontFamily();
}
